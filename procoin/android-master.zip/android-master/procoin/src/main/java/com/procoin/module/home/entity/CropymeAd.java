package com.procoin.module.home.entity;


import com.procoin.http.base.TaojinluType;

/**
 * Created by zhengmj on 17-5-22.
 */

public class CropymeAd implements TaojinluType {


    public long bannerId;
    public String pkg;
    public String cls;
    public String params;
    public String createTime;
    public String imageUrl;
    public int type;
    public int state;
    public String downTime;
    public int sortNum;
    public String videoUrl;
    public String upTime;



}
