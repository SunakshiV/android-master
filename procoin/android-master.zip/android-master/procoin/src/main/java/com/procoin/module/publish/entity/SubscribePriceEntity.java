//package com.tjr.imredz.module.publish.entity;
//
//import android.os.Parcel;
//import android.os.Parcelable;
//
//import TaojinluType;
//
///**
// * Created by zhengmj on 18-11-13.
// */
//
//public class SubscribePriceEntity implements TaojinluType {
//    public int duration;// 订阅时长
//    public int timeUnit;// 时长单位，0:小时，1:天，2:月，3:年，4:永久
//
//    public int price;// 购买价格
//    public String symbol;
//
//    public long subplanId;
//    public long projectId;
//
//
//    @Override
//    public String toString() {
//        return "duration=" + duration + "  timeUnit=" + timeUnit + " price=" + price + " symbol=" + symbol + "  subplanId==" + subplanId + "  projectId==" + projectId;
//    }
//}
