package com.procoin.common.photo;

public class ImageEntity {
	public String minPic;
	public String maxPic;

	public ImageEntity(String minPic, String maxPic) {
		this.minPic = minPic;
		this.maxPic = maxPic;
	}

//	public String getMinPic() {
//		return minPic;
//	}
//
//	public void setMinPic(String minPic) {
//		this.minPic = minPic;
//	}
//
//	public String getMaxPic() {
//		return maxPic;
//	}
//	public void setMaxPic(String maxPic) {
//		this.maxPic = maxPic;
//	}
}
