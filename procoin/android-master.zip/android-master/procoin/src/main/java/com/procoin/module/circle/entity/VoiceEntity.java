package com.procoin.module.circle.entity;

public class VoiceEntity {
	public String voiceUrl;
	public int voiceSecond;

	public VoiceEntity(String voiceUrl, int voiceSecond) {
		this.voiceUrl = voiceUrl;
		this.voiceSecond = voiceSecond;
	}

//	public String getVoiceUrl() {
//		return voiceUrl;
//	}
//
//	public void setVoiceUrl(String voiceUrl) {
//		this.voiceUrl = voiceUrl;
//	}
//
//	public int getVoiceSecond() {
//		return voiceSecond;
//	}
//
//	public void setVoiceSecond(int voiceSecond) {
//		this.voiceSecond = voiceSecond;
//	}

}
