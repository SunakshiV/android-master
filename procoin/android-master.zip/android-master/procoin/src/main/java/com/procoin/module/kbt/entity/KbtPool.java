package com.procoin.module.kbt.entity;

/**
 * ImageGroup.java
 * ImageChooser
 * <p>
 * Created by likebamboo on 2014-4-22
 * Copyright (c) 1998-2014 http://likebamboo.github.io/ All rights reserved.
 */

import com.procoin.http.base.TaojinluType;

/**
 *
 */
public class KbtPool implements TaojinluType {

    public String mySubAmount;
    public String price;
    public String priceCny;
    public String produceAmount;
    public long subId;
    public String symbol;
    public String totalAmount;

    public String[] amountList;






}
