package com.procoin.module.myhome.entity;

import com.procoin.http.base.TaojinluType;


public class Trend implements TaojinluType {


    public long dayTime;
    public String num;

}
