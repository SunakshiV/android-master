package com.procoin.module.home.entity;

/**
 * ImageGroup.java
 * ImageChooser
 * <p>
 * Created by likebamboo on 2014-4-22
 * Copyright (c) 1998-2014 http://likebamboo.github.io/ All rights reserved.
 */

import com.procoin.http.base.TaojinluType;

public class HomeCopyOrder implements TaojinluType {

//    public String balance;
//    public String copyHeadUrl;
//    public String copyName;
//    public String profitCash;
//    public String profitRate;
//    public String tolBalance;
//    public long copyUid;
//    public long orderId;
//    public long userId;


    public String copyHeadUrl;
    public String copyName;
    public String market;
    public String marketCny;
    public String profit;
    public String profitRate;
    public String tolBalance;
    public long userId;
    public long copyUid;
    public long orderId;





}
