package com.procoin.module.home;

import com.procoin.http.base.TaojinluType;

/**
 * Created by zhengmj on 19-5-14.
 */

public interface OnItemClick {
    void onItemClickListen(int pos, TaojinluType t);
}
