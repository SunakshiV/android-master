package com.procoin.subpush.connect.listen;


public interface RequestListen {
	void startRequest();
	void completeRequest();
}
