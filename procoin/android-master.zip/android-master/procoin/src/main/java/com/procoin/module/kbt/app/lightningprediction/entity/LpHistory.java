package com.procoin.module.kbt.app.lightningprediction.entity;

/**
 * ImageGroup.java
 * ImageChooser
 * <p>
 * Created by likebamboo on 2014-4-22
 * Copyright (c) 1998-2014 http://likebamboo.github.io/ All rights reserved.
 */

import com.procoin.http.base.TaojinluType;

/**
 *
 */
public class LpHistory implements TaojinluType {



    public String amount;
    public String createTime;
    public int  myVote;
    public String receive;
    public int result;
    public String resultDesc;

}
