package com.procoin.module.home.entity;

import com.procoin.http.base.TaojinluType;

public class YYBPool implements TaojinluType {

    public String destroyAmount;
    public String fromTime;
    public String produceAmount;
    public String repoPrice;
    public String repoPriceCny;
    public String toTime;

}