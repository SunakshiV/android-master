package com.procoin.module.circle.entity;

import com.procoin.http.base.TaojinluType;

/**
 * Created by zhengmj on 16-1-12.
 */
public class SocketFail implements TaojinluType {

    public int code;
    public String msg;
    public boolean success;
}
