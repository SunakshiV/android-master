package com.procoin.common.base;

public abstract interface ActionBarProgressBarListener {
	public abstract void progressBarShow();//acntiobar进度度显示
	public abstract void progressBarDismiss();//acntiobar进度度危隐藏
}
