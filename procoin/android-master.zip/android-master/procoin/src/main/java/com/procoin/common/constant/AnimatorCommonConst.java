package com.procoin.common.constant;

public class AnimatorCommonConst {
	public static final String SCALE_X = "scaleX";
	public static final String SCALE_Y = "scaleY";
	public static final String ALPHA = "alpha";
	public static final String TRANSLATION_X = "translationX";
	public static final String TRANSLATION_Y = "translationY";

	public static final String ROTATION = "rotation";
}
