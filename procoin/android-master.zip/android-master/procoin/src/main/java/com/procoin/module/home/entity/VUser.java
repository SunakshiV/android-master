package com.procoin.module.home.entity;

/**
 * ImageGroup.java
 * ImageChooser
 * <p>
 * Created by likebamboo on 2014-4-22
 * Copyright (c) 1998-2014 http://likebamboo.github.io/ All rights reserved.
 */

import com.procoin.http.base.TaojinluType;

public class VUser implements TaojinluType {

    public String correctRate;
    public String days;
    public String headUrl;
    public String monthProfit;
    public String totalProfit;
    public long userId;
    public String userName;

    public VUser(){}


}
