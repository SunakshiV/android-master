package com.procoin.module.wallet.entity;

/**
 * ImageGroup.java
 * ImageChooser
 * <p>
 * Created by likebamboo on 2014-4-22
 * Copyright (c) 1998-2014 http://likebamboo.github.io/ All rights reserved.
 */

import com.procoin.http.base.TaojinluType;

/**
 *
 */
public class CloseDetails implements TaojinluType {


    public String closeBail;
    public String closeFee;
    public String closeHand;
    public String closePrice;
    public String closeTime;
    public String profit;
    public String profitShare;


}
