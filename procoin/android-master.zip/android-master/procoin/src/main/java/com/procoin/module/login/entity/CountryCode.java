package com.procoin.module.login.entity;

import com.procoin.http.base.TaojinluType;

/**
 * Created by zhengmj on 19-9-26.
 */

public class CountryCode implements TaojinluType {
    public String code;
    public String name;
}
