package com.procoin.module.kbt.entity;

/**
 * ImageGroup.java
 * ImageChooser
 * <p>
 * Created by likebamboo on 2014-4-22
 * Copyright (c) 1998-2014 http://likebamboo.github.io/ All rights reserved.
 */

import com.procoin.http.base.TaojinluType;

/**
 *
 */
public class KbtNotice implements TaojinluType {

    public String articleId;
    public String createTime;
    public String isTop;
    public String title;
    public String type;
    public String url;

}
