package com.procoin.module.home.entity;

/**
 * ImageGroup.java
 * ImageChooser
 * <p>
 * Created by likebamboo on 2014-4-22
 * Copyright (c) 1998-2014 http://likebamboo.github.io/ All rights reserved.
 */

import com.procoin.http.base.TaojinluType;

public class Position implements TaojinluType {



    public String buySell;
    public String buySellValue;
    public String closeDone;
    public String closeFee;
    public String closePrice;
    public String closeState;
    public String closeStateDesc;
    public String closeTime;
    public String multiNum;
    public String nowStateDesc;
    public String openBail;
    public String openDone;
    public String openFee;
    public String openHand;
    public String openPrice;
    public String openState;
    public String openStateDesc;
    public String openTime;
    public String price;
    public String priceDecimals;
    public String profit;
    public String profitRate;
    public String stopLossPrice;
    public String stopWinPrice;
    public String symbol;
    public long  userId;
    public long orderId;
    public String hide;








}
