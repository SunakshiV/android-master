package com.procoin.module.home.entity;

/**
 * ImageGroup.java
 * ImageChooser
 * <p>
 * Created by likebamboo on 2014-4-22
 * Copyright (c) 1998-2014 http://likebamboo.github.io/ All rights reserved.
 */

import com.procoin.http.base.TaojinluType;

public class ScoreData implements TaojinluType {

    //下面是雷达图用到
    public String tolIncomeScore="0.00";// 高手收益率
    public String copyRateScore="0.00";// 用户跟单收益率
    public String profitShareScore="0.00";// 盈利占比
    public String copyNumScore="0.00";// 人气
    public String copyBalanceScore="0.00";// 跟单盈亏累计金额
    

}
