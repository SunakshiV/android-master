package com.procoin.subpush.connect.listen;


public interface BaseControlListen {
	void doControl(Object o);
}
